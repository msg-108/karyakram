"""
Thin API views. Every view delegates to `services` for anything beyond
request parsing / permission checks / response shaping.
"""
from __future__ import annotations

from django.shortcuts import get_object_or_404
from drf_spectacular.utils import (
    OpenApiExample,
    OpenApiResponse,
    extend_schema,
    inline_serializer,
)
from rest_framework import serializers, status
from rest_framework.generics import RetrieveAPIView
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView

from apps.dashboard.permissions import IsOrganizer
from . import services
from .models import EmailOTP, OrganizerProfile, User
from .serializers import (
    OrganizerApprovalActionSerializer,
    OrganizerProfileSerializer,
    OrganizerRegisterSerializer,
    OTPRequestSerializer,
    OTPVerifySerializer,
    UserPublicSerializer,
    UserRegisterSerializer,
    UserTokenObtainPairSerializer,
)

_DETAIL_RESPONSE = inline_serializer(
    name="DetailResponse", fields={"detail": serializers.CharField()}
)


# ==================== REGISTRATION ====================


class UserRegisterView(APIView):
    """Register a standard USER account. Inactive until email is verified."""

    permission_classes = [AllowAny]

    @extend_schema(
        operation_id="registerUser",
        summary="Register a user account",
        description=(
                "Create a new standard user account. "
                "The account is created inactive and a 6-digit verification OTP "
                "is sent to the registered email address. The user must verify "
                "their email before they can log in."
        ),
        tags=["Authentication"],
        request=UserRegisterSerializer,
        responses={
            201: OpenApiResponse(UserPublicSerializer, description="Account created; OTP sent."),
            400: OpenApiResponse(description="Validation error."),
        },
        examples=[
            OpenApiExample(
                "Request",
                value={
                    "username": "sitagharti",
                    "email": "sita@example.com",
                    "password": "S3cure!Pass",
                    "password_confirm": "S3cure!Pass",
                    "first_name": "Sita",
                    "last_name": "Gharti",
                },
                request_only=True,
            )
        ],
    )
    def post(self, request):
        serializer = UserRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(UserPublicSerializer(user).data, status=status.HTTP_201_CREATED)


class OrganizerRegisterView(APIView):
    """Register an ORGANIZER account. Inactive until email is verified AND admin-approved."""

    permission_classes = [AllowAny]
    # Explicit, since this endpoint accepts file uploads (citizenship/PAN
    # documents) alongside regular form fields — JSONParser alone can't
    # handle multipart bodies.
    parser_classes = [MultiPartParser, FormParser]

    @extend_schema(
        operation_id="registerOrganizer",
        summary="Register an organizer account",
        description=(
                "Create a new organizer account and upload the required "
                "verification documents. After email verification, the account "
                "must be approved by an administrator before login is allowed."
        ),

        tags=["Authentication"],
        request=OrganizerRegisterSerializer,
        responses={
            201: OpenApiResponse(UserPublicSerializer, description="Account created; OTP sent."),
            400: OpenApiResponse(description="Validation error."),
        },
    )
    def post(self, request):
        serializer = OrganizerRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(serializer.to_representation(user), status=status.HTTP_201_CREATED)


# ==================== EMAIL VERIFICATION (OTP) ====================


class VerifyEmailOTPView(APIView):
    """Verify the 6-digit OTP sent at registration. USER accounts activate
    immediately; ORGANIZER accounts remain inactive pending admin approval."""

    permission_classes = [AllowAny]

    @extend_schema(
        operation_id="verifyEmailOTP",
        summary="Verify email address",
        description=(
                "Verify the 6-digit OTP sent to the user's email address. "
                "Regular users become active immediately after verification. "
                "Organizer accounts remain pending until approved by an administrator."
        ),
        tags=["Email Verification"],
        request=OTPVerifySerializer,
        responses={
            200: OpenApiResponse(_DETAIL_RESPONSE, description="Email verified."),
            400: OpenApiResponse(description="Invalid/expired code, or too many attempts."),
        },
    )
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = get_object_or_404(User, email=serializer.validated_data["email"])

        result = services.verify_otp(
            user,
            code=serializer.validated_data["code"],
            purpose=EmailOTP.Purpose.EMAIL_VERIFICATION,
        )

        detail = (
            "Email verified. You can now log in."
            if result.activated
            else "Email verified. Your account is now awaiting admin approval."
        )
        return Response({"detail": detail}, status=status.HTTP_200_OK)


class ResendOTPView(APIView):
    """Resend the email-verification OTP, subject to a cooldown."""

    permission_classes = [AllowAny]

    @extend_schema(
        operation_id="resendVerificationOTP",
        summary="Resend verification OTP",
        description=(
                "Generate and send a new email verification OTP. "
                "Requests are subject to the configured resend cooldown period."
        ),
        tags=["Email Verification"],
        request=OTPRequestSerializer,
        responses={
            200: OpenApiResponse(_DETAIL_RESPONSE, description="A new code was sent."),
            400: OpenApiResponse(description="Cooldown still active, or no account found."),
        },
    )
    def post(self, request):
        serializer = OTPRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = get_object_or_404(User, email=serializer.validated_data["email"])

        services.resend_otp(user, purpose=EmailOTP.Purpose.EMAIL_VERIFICATION)
        return Response({"detail": "A new verification code has been sent."})


# ==================== LOGIN ====================


class LoginView(TokenObtainPairView):
    """
    Username + password login. Rejects (per requirement #9) when the
    email is unverified, the account is inactive, or an organizer is
    still pending admin approval — enforced in
    UserTokenObtainPairSerializer.validate() via services.assert_can_login.
    """

    serializer_class = UserTokenObtainPairSerializer

    @extend_schema(
        operation_id="login",
        summary="Authenticate user",
        description=(
                "Authenticate using username and password. "
                "Returns JWT access and refresh tokens. "
                "Login is denied if the email is unverified, "
                "the account is inactive, or the organizer "
                "is still awaiting administrator approval."
        ),
        tags=["Authentication"],
        responses={
            200: OpenApiResponse(description="Returns `access` and `refresh` JWTs."),
            400: OpenApiResponse(description="Invalid credentials, unverified email, or inactive account."),
            403: OpenApiResponse(description="Organizer account pending admin approval."),
        },
    )
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)


# ==================== PROFILE ====================


class MeView(RetrieveAPIView):
    """Return the authenticated user's own profile."""

    permission_classes = [IsAuthenticated]
    serializer_class = UserPublicSerializer

    def get_object(self) -> User:
        return self.request.user

    @extend_schema(
        operation_id="getCurrentUser",
        summary="Get current user profile",
        description=(
                "Return the authenticated user's profile information."
        ),
        tags=["Profile"],
        responses=UserPublicSerializer)

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


class MyOrganizerProfileView(RetrieveAPIView):
    """Return the authenticated organizer's OrganizerProfile."""

    permission_classes = [IsAuthenticated, IsOrganizer]
    serializer_class = OrganizerProfileSerializer

    def get_object(self) -> OrganizerProfile:
        return get_object_or_404(OrganizerProfile, user=self.request.user)

    @extend_schema(
        operation_id="getOrganizerProfile",
        summary="Get organizer profile",
        description=(
                "Return the authenticated organizer's profile information."
        ),
        tags=["Profile"],
        responses=OrganizerProfileSerializer,
    )

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


# ==================== ADMIN: ORGANIZER APPROVAL ====================


class PendingOrganizerListView(APIView):
    """List organizers awaiting approval (email verified, not yet approved). Admin only."""

    permission_classes = [IsAdminUser]

    @extend_schema(
        operation_id="listPendingOrganizers",
        summary="List pending organizers",
        description=(
                "Return all organizer accounts that have verified "
                "their email but are still waiting for administrator approval."
        ),
        tags=["Admin"],
        responses=OrganizerProfileSerializer(many=True),
    )
    def get(self, request):
        pending = OrganizerProfile.objects.filter(
            user__role=User.Role.ORGANIZER,
            user__is_email_verified=True,
            user__is_approved=False,
        ).select_related("user")
        return Response(OrganizerProfileSerializer(pending, many=True).data)


class OrganizerApprovalView(APIView):
    """Approve or reject a specific organizer's application. Admin only."""

    permission_classes = [IsAdminUser]

    @extend_schema(
        operation_id="approveOrRejectOrganizer",
        summary="Approve or reject organizer",
        description=(
                "Approve or reject an organizer registration request. "
                "Approving activates the account. Rejecting keeps the "
                "account inactive and stores the rejection reason."
        ),
        tags=["Admin"],
        request=OrganizerApprovalActionSerializer,
        responses={
            200: OpenApiResponse(
                OrganizerProfileSerializer,
                description="Organizer approval status updated."
            ),
            400: OpenApiResponse(
                description="Invalid approval request."
            ),
            404: OpenApiResponse(
                description="Organizer not found."
            ),
        },
    )

    def post(self, request, user_id: int):
        profile = get_object_or_404(OrganizerProfile, user_id=user_id)
        serializer = OrganizerApprovalActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        if serializer.validated_data["action"] == "approve":
            profile = services.approve_organizer(profile, admin=request.user)
        else:
            profile = services.reject_organizer(
                profile, admin=request.user, reason=serializer.validated_data["reason"]
            )
        return Response(OrganizerProfileSerializer(profile).data)